import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Enter the String 1:");
		Scanner obj=new Scanner(System.in);
		String str1=obj.nextLine();
		
		System.out.print("Enter the string 2:");
		String str2=obj.nextLine();
		
		String result=(str1.concat(str2));
		System.out.println(result);
	
	
		
		
	}
}