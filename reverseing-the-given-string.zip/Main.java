import java.util.*;
public class Main
{
	public static void main(String[] args) {
        
        String str="madam";
	    StringBuffer st= new StringBuffer(str);
	    String reversed=st.reverse().toString();
	    if(str.equals(reversed))
	    {
	        System.out.println("Palindrome");
	    }
	    else{
	        System.out.println("Not a Palindrome");
	    }
	}
}
