import java.util.*;
class Main{
    public static void main(String[] args)
    {
        Scanner obj=new Scanner(System.in);
        int arr[]=new int[5];
        System.out.print("Enter any five numbers:");
        for(int i=0; i< arr.length;i++)
        {
            arr[i]=obj.nextInt();
        }
        System.out.println(" your grade:");
        for(int i=0; i< arr.length; i++)
        {
            System.out.println(arr[i]);
        }
    }
}