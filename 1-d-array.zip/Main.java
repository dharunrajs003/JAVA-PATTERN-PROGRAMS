import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner obj=new Scanner(System.in);
	    System.out.print("Enter the no to find the Index:");
	    int n=obj.nextInt();
	    int[] arr=new int[n];
	    System.out.println("Enter Elements:");
	    for(int i=0;i<n;i++)
	    {
	        arr[i]=obj.nextInt();
	        
	    }
	    System.out.println("various marks of Batch 12:");
	    int value=obj.nextInt();
	    int count=0;
	    for(int i=0;i<n;i++)
	    {
	        if(arr [i]== value)
	        {
	            count++;
	        }
	    }
	    System.out.println(count);
	}
}