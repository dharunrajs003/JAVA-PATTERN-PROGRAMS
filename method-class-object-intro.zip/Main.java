import java.util.*;
class Demo
{
	 
		String name;
		int age;
		public void display()

{		System.out.println("Name:"+name);
		System.out.println("Age:"+age);
		
	}
}
public class Main{
    public static void main(String[] args)
    {
        Demo ksr=new Demo();
        ksr.name="Dahrun raj";
        ksr.age=19;
        ksr.display();
        
    }
}
