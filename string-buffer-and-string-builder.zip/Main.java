// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 	    StringBuilder str= new StringBuilder("java developer");
// 	    str.insert(5,"Programming ");
// 	    System.out.println(str);
// 	}
// }



import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    StringBuffer str= new StringBuffer("java developer");
	    str.appe(5,"Programming ");
	    System.out.println(str);
	}
}


