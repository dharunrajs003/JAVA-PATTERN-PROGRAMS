import java.util.*;
class Main{
    public static void main(String[] args)
    {
       Scanner obj=new Scanner(System.in);
       System.out.print("Enter the String :");
       String str=obj.nextLine();
       String temp="";
       for(int i=str.length()-1;i>=0;i--)
       {
           temp+= str.charAt(i);
       }
       
       System.out.print(temp);
    }
}
