
class ksr {
	public static  int add(int a,int b) {
	
		int c = a+b;
		return c;
	}
}


public class Main {
	public static void main(String[] args)
	{
		int result=ksr.add(10,20);
		System.out.println(result);
	}
}
