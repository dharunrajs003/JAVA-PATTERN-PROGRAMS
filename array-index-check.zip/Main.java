import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner obj=new Scanner(System.in);
		System.out.print("Enter the Size of Array:");
		int size=obj.nextInt();
		int [] arr= new int[size];
		int indexvalue=0;
		System.out.println("Enter the array elemnts");
		for(int i=0;i<size;i++)
		{
		    arr[i]=obj.nextInt();
		    
		}
		System.out.println("enter the value to find the index:");
		int value=obj.nextInt();
		
		 for(int j=0;j<size;j++)
		 {
		     if(arr[j]==value)
		     {
		         indexvalue=j;
		     }
		     
		 }
		 System.out.println("the index value is:"+indexvalue);
	}
}
