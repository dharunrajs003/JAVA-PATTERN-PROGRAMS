import java.util.*;
public class Main
{
	public static void main(String[] args) {
        String str="Dharun Raj";
        System.out.println("Substring:"+str.substring(2,8));
        System.out.println("contains:"+str.contains("Raj"));
        System.out.println("Equals of String:"+str.equals("Dharun Raj"));
        System.out.println("Index of the string: "+str.indexOf("a"));
        System.out.println("Index of the string: "+str.lastIndexOf("a"));
        System.out.println("Replacing the String:"+str.replace("Raj","Bro"));
        System.out.println("Replacing the String:"+str.replaceAll("a","A"));

	}
}