    import java.util.*;
    class Main{
        public static void main(String[] args)
        {
            Scanner obj = new Scanner(System.in);
            System.out.print("Enter the no of student:");
            int n=obj.nextInt();
            int[] arr=new int[n];
            System.out.println("enter the marks:");
            int sum=0;
            for(int i=0;i<n;i++)
            {
                arr[i]=obj.nextInt();
                
            }
            int max=arr[0],min=arr[0];
            for(int i=0;i<n;i++)
            {
                if(arr[i]>max){
                 max=arr[i];     
                
                }
                if(arr[i]<min)
                {
                    min=arr[i];
                }
            }
            System.out.println("Maximum mark"+max);
            System.out.println("Minimum mark"+min);
            if(max>=60)
            {
                System.out.println("pass");
            }
            else{
                System.out.println("fail");
            }
        }
    }
